/* This program will play a simple guessing game.
 * The user will guess, and the computer should print if
 * the guess was too high, too low, or correct.
 */
function start(){
    var secretNum = Randomizer.nextInt(1, 100);
    while(true){
        var guess = readInt("Guess a number: ");
        if(guess > secretNum){
            sayHigh();
        }else if(guess < secretNum){
            sayLow();
        }else if(guess == secretNum){
            println("You got it!");
            break;
        }
    }
}
function sayHigh(){
    println("High.");
}
function sayLow(){
    println("Low.");
}