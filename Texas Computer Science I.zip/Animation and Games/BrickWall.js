const BRICK_WIDTH = 50;
const BRICK_HEIGHT = 20;

function main() {
    
}