/* This program creates a more colorful painting ability
using the mouse click and drag methods. The user can select
a color above and then drag to paint below the divider line.

Take a look at the `paint()` and `selectColor()` functions. 
Can you see how they use the mouse coordinates to paint (that 
is, create circles) and select a color? Why does each function 
use a an `if` conditional? What are purposes of each condition?

*/

const BUTTON_SIZE = 50;
const DIVIDER_Y = 120;
const PAINT_RADIUS = 15;

// This sets the default color of the paint brush
let color = "black";

function main(){
    // Initializes the screen
    initScreen();
    
    mouseClickMethod(selectColor);
	mouseDragMethod(paint);
}

// This function creates a colored circle while the mouse
// is dragging below the divider line
function paint(e){
    let x = e.getX();
    let y = e.getY();
    
    // Creates a circle only if mouse drag is below divider line
    if (y > DIVIDER_Y + PAINT_RADIUS) {
    	let circle = new Circle(PAINT_RADIUS);
    	circle.setColor(color);
    	circle.setPosition(x, y);
    	add(circle);
    }
}

// This function sets the value of the global color variable
// when one of the color rectangles is clicked
function selectColor(e) {
    let obj = getElementAt(e.getX(), e.getY());
    
    if (obj != null && obj.type == "Rectangle") {
        color = obj.getColor();
    }
}

// This function initializes the paint programs screen by adding
// text, color buttons, and a divider line
function initScreen() {
    let text = new Text("Click for a color!");
    text.setPosition(0, text.getHeight());
    add(text);
    
    addColorButtons("red", "orange", "teal");
    
    let divider = new Line(0, DIVIDER_Y, getWidth(), DIVIDER_Y);
    add(divider);
}

// This function creates three color buttons using parameters
function addColorButtons(color1, color2, color3) {
    let button1 = new Rectangle(BUTTON_SIZE, BUTTON_SIZE);
    button1.setPosition(0, 50);
    button1.setColor(color1);
    add(button1);
    
    let button2 = new Rectangle(BUTTON_SIZE, BUTTON_SIZE);
    button2.setPosition(100, 50);
    button2.setColor(color2);
    add(button2);
    
    let button3 = new Rectangle(BUTTON_SIZE, BUTTON_SIZE);
    button3.setPosition(200, 50);
    button3.setColor(color3);
    add(button3);
}

main();