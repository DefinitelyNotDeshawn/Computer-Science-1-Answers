const RADIUS = 25;
const DELAY = 40;

function main(){
	
}