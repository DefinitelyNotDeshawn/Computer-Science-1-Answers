/* This program uses a timer and the Randomizer to draw circles
on the canvas until MAX_CIRCLES is reached */

const MAX_RADIUS = 100;
const MAX_CIRCLES = 100;
let counter = 0;

function main() {
	setTimer(draw, 50);
}

function draw() {
    let newRadius = Randomizer.nextInt(0, MAX_RADIUS);
    let newColor = Randomizer.nextColor();
    let newX = Randomizer.nextInt(0, getWidth());
    let newY = Randomizer.nextInt(0, getHeight());
	
	drawCircle(newRadius, newColor, newX, newY);
	counter++;
	
	// Once the max circles is reached, we stop the timer
	if (counter == MAX_CIRCLES) {
		stopTimer(draw);
	}
}

function drawCircle(radius, color, x, y) {
	let circle = new Circle(radius);
	circle.setColor(color);
	circle.setPosition(x, y);
	add(circle);
}

main();