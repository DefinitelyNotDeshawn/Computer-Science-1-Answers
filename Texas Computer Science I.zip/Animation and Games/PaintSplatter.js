const CIRCLES_PER_SPLATTER = 20;
const MIN_RADIUS = 5;
const MAX_RADIUS = 25;
const DELAY = 500;

function main() {
   
}