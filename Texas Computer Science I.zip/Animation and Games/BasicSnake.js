/* This program is the beginning of the classic snake game. It
creates a snake that the user is able to move with key commands.
*/

const CENTER_X = getWidth() / 2;
const CENTER_Y = getHeight() / 2;
const DELAY = 200;

const SNAKE_SIZE = 20;
const SNAKE_COLOR = "green";

let dx = SNAKE_SIZE;
let dy = 0;
let snake;

function main() {
    snake = initSnake(SNAKE_SIZE, SNAKE_SIZE, "green", CENTER_X - SNAKE_SIZE / 2, CENTER_Y - SNAKE_SIZE / 2);
   
setTimer(move, DELAY);
keyDownMethod(changeDir);
}

// This function adds and initializes the snake with parameters
function initSnake(width, height, color, x, y) {
let rect = new Rectangle(width, height);
rect.setColor(color);
rect.setPosition(x, y);
add(rect);

return rect;
}

// This function changes the direction of the snake whenever the
// user presses down on an arrow key
function changeDir(e){
if(e.key == "ArrowLeft"){
dx = -SNAKE_SIZE;
        dy = 0;
} else if(e.key == "ArrowRight"){
dx = SNAKE_SIZE;
        dy = 0;
} else if(e.key == "ArrowUp"){
        dx = 0;
        dy = -SNAKE_SIZE;
} else if(e.key == "ArrowDown"){
dx = 0;
        dy = SNAKE_SIZE;
}
}

// This function is continually called in the timer and moves
// the snake with the values in dx and dy
function move(){
snake.move(dx, dy);
}

main();