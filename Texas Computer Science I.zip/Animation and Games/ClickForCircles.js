/* This program draws a circle wherever the user clicks. */
function main() {
	mouseClickMethod(drawCircle);
}

function drawCircle(e) {
	let circle = new Circle(20);
	circle.setPosition(e.getX(), e.getY());
	circle.setColor(Randomizer.nextColor());
	add(circle);
}

main();