/* This program demonstrates how to create a timer to
move a graphic continuously, taking advantage of the 
.move(dx, dy) function.

Try changing the value of the delay in the timer and the
values in the move() function to see how it affects the animation! 
*/

let basketball;

function main() {
    // Adds a ball to the canvas and stores it in the 
    // basketball variable
    basketball = initBall(30, "#E47041", 50, 50);
    
	// Creates a timer that calls draw ever 20 milliseconds
	setTimer(draw, 20);
}

// This function initializes a ball by receiving the 
// parameter values, adding it to the canvas, and returning
// the graphic so that it can be stored in a variable
function initBall(radius, color, x, y) {
	let ball = new Circle(radius);
	ball.setPosition(x, y);
	ball.setColor(color);
	add(ball);
	
	return ball;
}

function draw() {
    // Moves the ball 2 pixels in each direction
	basketball.move(2, 2);
}

main();