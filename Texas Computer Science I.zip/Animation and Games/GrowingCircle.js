/* This program draws a growing circle that stops when it 
reaches the height of the canvas. */

const START_RADIUS = 1;
const INCREMENT = 1;
const CHANGE_COLORS_AT = 10;
const DELAY = 50;

function main(){

}