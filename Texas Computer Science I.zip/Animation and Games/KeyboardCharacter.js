/* This program uses keyboard arrows to change the image 
and move the character. Press the arrow keys and see
what happens!

Can you modify it so that you can also use the keys W, A,
S, and D to do the same thing? */

const STAND = "https://codehs.com/uploads/fedefa616d13d2727c1cf0658defec84";
const RIGHT = "https://codehs.com/uploads/79bd5a169b283d1f5e802c4c9f09bd18";
const LEFT = "https://codehs.com/uploads/741c1fca4ae20de824bde701f0f36cb6";
const UP = "https://codehs.com/uploads/abbaa5fa6a24e0dbba2222f756db7fe7";
const CENTER_X = getWidth() / 2;
const CENTER_Y = getHeight() / 2;

let dino;

function main() {
    initBackground("#a243b5", CENTER_X * 2, CENTER_Y, 0, CENTER_Y);
    initBackground("#b6e8fa", CENTER_X * 2, CENTER_Y, 0, 0);
    dino = initCharacter(STAND, CENTER_X, CENTER_Y);
    
    keyDownMethod(changeDirection);
}

// This function changes the image and moves the character based
// on keyboard presses
function changeDirection(e) {
	if (e.key == "ArrowUp") {
		dino.setImage(UP);
	}
	
	if (e.key == "ArrowDown") {
		dino.setImage(STAND);
	}
	
	if (e.key == "ArrowRight") {
		dino.setImage(RIGHT);
		dino.move(5, 0);
	}
	
	if (e.key == "ArrowLeft") {
		dino.setImage(LEFT);
		dino.move(-5, 0);
	}
}

// This function adds and initializes a character webimage
function initCharacter(image, x, y) {
    let character = new WebImage(image);
    character.setPosition(x - 60, y - 113);
    add(character);
    
    return character;
}

// This function adds and initializes a rectangle
function initBackground(color, w, h, x, y) {
    let rec = new Rectangle(w, h);
    rec.setColor(color);
    rec.setPosition(x, y);
    add(rec);
}

main();