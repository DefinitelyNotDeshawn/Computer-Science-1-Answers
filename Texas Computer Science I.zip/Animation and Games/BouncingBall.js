/* This program has a ball rolling across a floor,
bouncing off the left and right walls.
*/

const FLOOR_Y = 200;
const BIG_RADIUS = 50;
const DELAY = 20

let bigBall;

// This is how much the ball will move every DELAY milliseconds 
let dx = 4;

function main(){
    bigBall = initBall(BIG_RADIUS, "#b0f542", 100, FLOOR_Y - BIG_RADIUS);
	createFloor(getWidth(), getHeight() - FLOOR_Y, "#e2725b", 0, FLOOR_Y);
	
	setTimer(draw, DELAY);
}

// This function adds the ball to the canvas with parameters
function initBall(radius, color, x, y){
	let ball = new Circle(radius);
	ball.setPosition(x, y);
	ball.setColor(color);
	add(ball);
	
	return ball;
}

// This function creates a rectangular floor with parameters
function createFloor(width, height, color, x, y){
    let floor = new Rectangle(width, height);
    floor.setPosition(x, y);
    floor.setColor(color);
    add(floor);
}

// This function moves the ball, checking to see if it has
// collided with walls.
function draw(){
	checkWalls();
	bigBall.move(dx, 0);
}

// This function checks to see if the ball has hit the left
// or right wall, reversing it's dx value.
function checkWalls(){
	// Bounce off right wall
	if(bigBall.getX() + bigBall.getRadius() >= getWidth()){
		dx = -dx;
	}
	
	// Bounce off left wall
	if(bigBall.getX() - bigBall.getRadius() <= 0){
		dx = -dx;
	}
}

main();