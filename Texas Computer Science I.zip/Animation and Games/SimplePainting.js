/* This program creates a simple painting ability with the
mouse move method */

function main() {
	mouseMoveMethod(paint);
}

// This function creates a new circle every time the mouse
// is moved on the canvas
function paint(e) {
	let circle = new Circle(15);
	circle.setPosition(e.getX(), e.getY());
	add(circle);
}

main();