/* This program draws a magic 8 ball on the screen and shakes
it every 2 seconds. Shaking means it changes the number and 
color of the ball.

To do this, we set a timer rather than use a loop so that we can 
set a time delay.
 */

const CENTER_X = getWidth() / 2;
const CENTER_Y = getHeight() / 2;
const RADIUS = 120;
const FONT = "48pt Arial";

let magicBall;
let number;

function main() {
    // Creates and initializes the ball and text, storing them
    // in the variables
	magicBall = initBall(RADIUS, "black", CENTER_X, CENTER_Y);
    number = initText("8", FONT, "white", CENTER_X, CENTER_Y);

	// Set a timer to call the shake function every 2 seconds
	setTimer(shake, 2000);
}

// This function initializes a ball, adds it to the canvas,
// and returns it to be stored in a variable
function initBall(radius, color, x, y) {
	let ball = new Circle(radius);
	ball.setPosition(x, y);
	ball.setColor(color);
	add(ball);
	
	return ball;
}

// This function initializes a text, adds it to the canvas,
// and returns it to be stored in a variable
function initText(text, font, color, x, y) {
    let num = new Text(text, font);
	num.setPosition(x - num.getWidth() / 2, y + num.getHeight() / 2);
	num.setColor(color);
	add(num);
	
	return num;
}

/* This function sets the text of number to a random number and changes
the color of the circle to a random color. Note how it does not 
create a new Circle or new Text. It just uses the global ones 
we created. */
function shake() {
	let randomNumber = Randomizer.nextInt(1, 9);
	let randomColor = Randomizer.nextColor();
	
	number.setText(randomNumber);
	magicBall.setColor(randomColor);
}

main();