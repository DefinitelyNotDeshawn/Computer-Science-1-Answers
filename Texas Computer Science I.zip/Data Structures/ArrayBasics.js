/* This program creates two arrays and shows how to access the
items in the array with the indexes. 

Try changing the values of the items and indexes in the 
console.log()s and see what happens. */

function main() {
	let testScores = [95, 88, 85, 70, 98];
	console.log("First item (index 0): " + testScores[0]);
	console.log("Fourth item (index 3): " + testScores[3]);
	console.log();
	
	let shoppingList = ["bread", "eggs", "milk", "cookies"];
	let itemIndex = 2;
	console.log("Item at index " + itemIndex + ": " + shoppingList[itemIndex]);
	
	// Let's get cake instead of milk
	shoppingList[itemIndex] = "cake";
	console.log("Item at index " + itemIndex + ": " + shoppingList[itemIndex]);
}

main();