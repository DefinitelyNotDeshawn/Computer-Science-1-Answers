/* This example demonstrates the use of these array modification and 
conversion methods.

Try changing the values of the indices used in the splice() and slice()
methods. Is the change as expected?

Try using a different separating value, like " " or "|". Try uncommenting
lines 67 and 68, which use a new line (\n) and asterisk (*) separator to
create a bulleted list.
*/

function main() {
	let toDo = [
		"clean dishes",
		"fold laundry",
		"walk cat",
		"call mom",
		"practice piano"
	]
	console.log("==============SLICE===================");
	console.log();

	// Grabs items 0 and 1 and copies to new array
	let ryanTasks = toDo.slice(0, 2);
	// Grabs all items from index 2 onwards and copies to new array
	let steveTasks = toDo.slice(2);

	console.log("Ryan's tasks:");
	printTasks(ryanTasks);
	console.log("Steve's tasks:");
	printTasks(steveTasks);

	// Notice original array is not altered
	console.log("To do list:");
	printTasks(toDo);

	console.log("==============SPLICE===================");
	console.log();

	// Here splice starts at index 1 and removes 3 items from toDo
	// array, returning them as a new array
	let libbyTasks = toDo.splice(1, 3);
	console.log("Libby's tasks:");
	printTasks(libbyTasks);

	// Notice that the original array is now different. In this example,
	// using splice allows us to assign the middle three tasks to one
	// person, leaving the two end tasks to assign to someone else
	console.log("Remaining tasks:");
	printTasks(toDo);

}

// This function prints each item in the parameter array
function printTasks(list) {
	// When you pass an array as a parameter, the array is NOT a copy,
	// but a reference to the original array. Using slice method allows 
	// us to create a copy so that we don't accidentally modify the
	// original array
	let listCopy = list.slice();

	// The join method combines all the items in the array into one
	// string, separating each item by a comma and space in this case
	let itemList = listCopy.join(", ");
	
	// Try uncommenting these two lines to create a bullet-point style list
	// listCopy[0] = " * " + listCopy[0];
	// itemList = listCopy.join("\n * ");

	console.log(itemList);
	console.log();
}

main();