/* This program creates a snow storm by continually cycling through
all of the snowflakes in an array and moving them based on their 
size. This creates a parallax where flakes further back are smaller
and move slower. Again, this would be very hard to implement if you
needed a variable to track every single flake.

Try changing the number of flakes, the radii of the flakes, and the
speed of the flakes to see how it effects the final result! */

const FLAKE_COUNT = 200;
const GROUND = 300;

// Array that stores all of the snowflakes
let snow = [];

function main() {
    // Create the background and initial snowflakes
    initBackground("#a9b7cf", "#f7f7f7");
    initSnow(FLAKE_COUNT, "#f7f7f7");
    
    setTimer(fall, 20);
}

function fall() {
    // Cycle through each snowflake
    for (let i = 0; i < snow.length; i++) {
        let flake = snow[i];
        
        // Move at different speeds based on radius of flake
        if (flake.getRadius() == 1) {
            flake.move(0, 1);
        } else if (flake.getRadius() == 2) {
            flake.move(0.1, 2);
        } else if(flake.getRadius() == 3) {
            flake.move(-0.1, 3);
        } else if(flake.getRadius() == 4) {
            flake.move(-0.1, 3.5);
        } else {
            flake.move(0.1, 4);
        }

        // Reset the flake when it hits the ground
        if (flake.getY() > GROUND) {
            let x = Randomizer.nextInt(0, getWidth());
            flake.setPosition(x, 0);
        }

    }
}

// This function initializes the circles on the canvas
function initSnow(count, color) {
    for (let i = 0; i < count; i++) {
        let x = Randomizer.nextInt(0, getWidth());
        let y = Randomizer.nextInt(0, GROUND);
        let radius = Randomizer.nextInt(1, 5);
        let circle = new Circle(radius);
        circle.setPosition(x, y);
        circle.setColor(color);
        add(circle);
        snow.push(circle);
    }
}

// This function initializes the sky and ground
function initBackground(colorSky, colorGround) {
    let sky = new Rectangle(getWidth(), getHeight());
    sky.setColor(colorSky);
    add(sky);

    let ground = new Rectangle(getWidth(), 300);
    ground.setPosition(0, GROUND);
    ground.setColor(colorGround);
    add(ground);
}

main();