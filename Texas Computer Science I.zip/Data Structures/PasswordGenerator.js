let characters = "abcdefghijklmnopqrstuvwxyz123456789";

function main() {
    
}