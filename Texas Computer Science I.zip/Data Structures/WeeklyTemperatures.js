/* This example demonstrates the use of these array iteration methods. All 
of them require a callback function as an argument, and there are two 
ways to implement it. The first approach is most consistent with how 
we've created callback functions in this course; the second approach 
is a bit more concise. This example uses both approaches. Can you spot 
them? Try changing them to use the other approach.
*/

function main() {
    let tempsF = [67, 22, 60, 55, 51];
    printTemps(tempsF);
    console.log();

    // The map method calls the covertFtoC function for every item
    // in the tempsF array (with the item as the parameter). Using 
    // map method will return a new array tempsC without changing tempsF
    let tempsC = tempsF.map(convertFtoC);
    printTemps(tempsC);
    console.log();

    // The every method calls the function for every item in the
    // tempsC array (with the item as the parameter). Using every method
    // will return true only if all items meet the function condition
    let allAboveZero = tempsC.every(function(temp) {
        return temp > 0;
    });

    // The some method calls the function for every item in the
    // tempsC array (with the item as the parameter). Using some method
    // will return true if at least one item meets the function condition
    let someBelowZero = tempsC.some(function(temp) {
        return temp < 0;
    });
    
    console.log("All above 0: " + allAboveZero);
    console.log("Some below 0: " + someBelowZero);
}

// Prints all of the temperatures in the array
function printTemps(temps) {
    // The forEach method calls the function for every item in the
    // temps array (with the item and its index as the parameters). Using
    // the forEach method does NOT return anything.
    temps.forEach(test);
}

// This function converts each individual temp from F to C
function convertFtoC(temp) {
    return Math.round((temp - 32) * (5/9));
}

function test(temp, index) {
    console.log("Temperature " + (index + 1) + " (" + "): " + temp);
}

main();