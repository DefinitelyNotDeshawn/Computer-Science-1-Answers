// Density of iron in g/cm^3
const DENSITY = 7.874; 

// Collected data of weights in lbs
let data = [0.35, 0.20, 1.52, 0.12, 0.85, 0.48, 0.39, 0.94, 1.43, 0.65, 0.68, 1.09, 0.77, 1.1, 0.34];

function main() {
    // Make a copy of the data so we don't alter original array. Use this array
    // in your program:
    let lbWeights = data.slice();

}

main();