// Two people's list of friends. DO NOT CHANGE THESE LISTS!!
let friends1 = [
    'John', 'Richard', 'Andrew', 'Daniel', 
    'Ernest', 'Will', 'Jesse', 'Oscar', 
    'William', 'Charles', 'Frank', 'Joseph', 
    'Thomas', 'Henry', 'Edward', 'Harry', 
    'Walter', 'Fred', 'Samuel', 'David', 
    'Louis', 'Joe'];

let friends2 = [
    'William', 'James', 'George', 'Frank', 
    'Thomas', 'Henry', 'Robert', 'Arthur', 
    'Fred', 'Lewis', 'Peter', 'Benjamin', 
    'Frederick', 'Willie', 'Alfred', 'Roy',
    'Herbert', 'Albert', 'Samuel', 'Louis'];

function main() {
    // Print how many friends each person has:
    
    
    
    
    // Call your findMutual function and print the number and list
    // of the mutual friends:
   
   
   
}


main();