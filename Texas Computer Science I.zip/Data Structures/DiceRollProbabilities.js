// Sets the number of rolls that occurs within a sample
const NUM_ROLLS = 100;

function main() {

}
