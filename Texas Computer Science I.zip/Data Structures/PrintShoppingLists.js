/* This program iterates through two loops using two different
techniques -- the length property and the for...of loop. 

Which technique do you prefer? If you just want to access the
items within an array, which technique is easiest? If you need
the indices of the items as well, which do you have to use? */

function main() {
	let listOne = ["bread", "eggs", "milk", "cookies"];
	
	let listTwo = ["beets", "coffee", "chips", "shrimp", "bananas",
				"tuna", "lettuce", "yogurt", "cheese", "chicken", 
				"cucumbers", "orange juice", "salt", "doritos", 
				"lemonade", "apples", "paper towels", "red onion", 
				"minced garlic", "turmeric", "donuts", "bagels", 
				"crackers", "red pepper", "green pepper", "spinach", 
				"avacado oil", "vanilla", "flour", "brown sugar", 
				"powdered sugar", "lime"];

	// Iterating through listOne using the .length property
	console.log("LIST ONE:");
	for (let i = 0; i < listOne.length; i++) {
		let cur = listOne[i];
		console.log(cur);
	}
	
	// Iterating through listTwo using for...of loop
	console.log();
    console.log("LIST TWO:");
	for(let item of listTwo){
		console.log(item);
	}
}

main();