function main() {
    let lyric1 = "Don't be trapped";
    let lyric2 = "in someone else's dream."; //by BTS
    
    let n = lyric1[2];
    console.log(n);
    
    let index = 4;
    let o = lyric2[4];
    console.log(o);
    
    let song = n + "." + o;
    console.log("From the song " + song);
}

main();