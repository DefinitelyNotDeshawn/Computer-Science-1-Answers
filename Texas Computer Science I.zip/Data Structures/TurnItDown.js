function main() {
    let text = "WHAT ARE YOU DOING TODAY?!";
    
}

//write your turnItDown function here