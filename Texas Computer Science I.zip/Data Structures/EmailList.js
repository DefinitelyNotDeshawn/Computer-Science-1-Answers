/* This example demonstrates the use of these array search methods.

Try uncommenting the console print on line 30 to witness the index
of each email being sent in. Did it print what you expected?

Try writing your own includes() and indexOf() calls.
*/

let emailAddresses = [
    "dog@codehs.com",
    "turtle@codehs.com",
    "owl@codehs.com",
    "snake@codehs.com" ];

function main() {
    checkEmail("turtle@codehs.com");
    checkEmail("cat@codehs.com");

    addEmail("owl@codehs.com");
    addEmail("hippo@codehs.com");
    
    printEmails();
}

// This function checks to see if a passed-in email is in the 
// emailAddresses array using the indexOf method.
function checkEmail(email) {
    // Returns the index of the email in the array
    let index = emailAddresses.indexOf(email);
    // console.log(index);
    
    // Index will be -1 if it is not in the array
    if (index != -1) {
        console.log(email + " is in the list.");
    } else {
        console.log(email + " is not in the list.");
    }
    console.log();
}

// This functions uses the includes method to first check to 
// see if the email is not already in the array. If it is not,
// it then adds the email to the array
function addEmail(email) {
    // If the email is not included in the array, then add it
    if (!emailAddresses.includes(email)) {
        emailAddresses.push(email);
    } else {
        console.log(email + " is already in the list");
        console.log();
    }
}

// This function loops through all of the emails in the array
// and prints each one.
function printEmails() {
    for (let email of emailAddresses) {
        console.log(email);
    }
    console.log();
}

main();