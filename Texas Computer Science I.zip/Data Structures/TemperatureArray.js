/* This program starts with a blank temperature array and then,
using the push method, adds temperature data that was randomly
collected throughout the month. Notice that the pop method removes
the last item from the array.

Can you rearrange the push lines so that the temperature of 88
is removed from the array with the pop method? */

function main() {
	// Create an empty array
	let temperatures = [];

	// Push lets you add to the array
	temperatures.push(80);
	temperatures.push(88);
	temperatures.push(87);
	temperatures.push(90);

	// Print our the array
	console.log(temperatures);
	console.log();

	// Pop removes the last element
	let last =  temperatures.pop();
	console.log("Pop: " + last);
	console.log();
	
	// Notice the last temperature is no longer in the array
	console.log(temperatures);
}

main();