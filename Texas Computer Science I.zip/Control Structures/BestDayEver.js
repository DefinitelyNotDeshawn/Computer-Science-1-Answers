//Write 5 Boolean variables that describe the conditions for the best day ever!
/* This program should declare a boolean that describes whether or not you have a dog. Then it prints out an informative message to the user. */
function main() {
	let isSunny = true;
	console.log("Is it sunny ");
	console.log(typeof(isSunny));
	
    let isWindy = false;
	console.log("Is it windy ");
	console.log(typeof(isWindy));
	
	    let isFoggy = false;
	console.log("Is it foggy ");
	console.log(typeof(isFoggy));
	
		    let isItCold = false;
	console.log("Is it cold outside ");
	console.log(typeof(isWindy));
	
		    let isAPefrectDay = true;
	console.log("Is it a perfect day ");
	console.log(typeof(isAPerfectDay));


	
	console.log("Is it a perfect day?: " + isSunny);
	
}

main();