/*
Right now, this program draws circle in a line. 
How can we adjust the program so that the circles go in a diagonal line rather than a straight line across?
*/
function main() {
    let radius = 20;
    //Sets the starting x and y position so that the first circle is entirely on the screen
    let x = radius;
    let y = radius;
    
    while (x < getWidth()) {
        let circle = new Circle(radius);
        circle.setPosition(x, y);
        circle.setColor(Randomizer.nextColor());
        circle.debug = true;
        add(circle);
        
        //adds a circle length (a diameter, or 2 times the radius) to the x position
        x = x + (2 * radius);
    }
}

main();