//Sample solution:

function main() {
    let answer = readLine("What is the capital of Tennessee? ");
   
    if (answer == "Nashville" || answer == "nashville") {
        drawCorrectScreen();
    } else {
        drawIncorrectScreen();
    }
}

function drawCorrectScreen() {
    // Adds an image
    let image = new WebImage("https://codehs.com/uploads/97afdabd4daa52727bcf38bb53d0d7bf");
    add(image);
    image.setSize(300, 250);
    image.setPosition(getWidth()/2 - image.getWidth()/2, getHeight()/2 - image.getHeight()/2);
   
    // Adds win text
    let text = new Text("Correct!", "80pt Arial");
    add(text);
    text.setPosition(getWidth()/2 - text.getWidth()/2, 100);
    text.setColor("lime");
}

function drawIncorrectScreen() {
    // Adds incorrect image
    let image = new WebImage("https://codehs.com/uploads/b1d0c18ddffdff2e7be946811077ddc1");
    add(image);
    image.setSize(350, 250);
    image.setPosition(getWidth()/2 - image.getWidth()/2, getHeight()/2 - image.getHeight()/2);
   
    // Adds incorrect text
    let text = new Text("Wrong!", "80pt Arial");
    add(text);
    text.setPosition(getWidth()/2 - text.getWidth()/2, 100);
    text.setColor("magenta");
}

main();