/*
This exercises shows two different ways to draw 500 circles on the canvas. The first portion of the program uses a for loop to draw the circles. The second portion uses a while loop to draw the circles. 

Try uncommenting the while loop and commenting out the for loop to see how these two program accomplish the same task.
*/

const MAX_CIRCLES = 500;

function main() {
    
    // For loop to create MAX_CIRCLES circles
    for (let i = 0; i < MAX_CIRCLES; i++) {
        let circle = new Circle(50);
        
        //Sets the x and y position to a random position
        let x = Randomizer.nextInt(0, getWidth());
        let y = Randomizer.nextInt(0, getHeight());
        circle.setPosition(x, y);

        //Sets the color to a random color
        circle.setColor(Randomizer.nextColor());
        add(circle);
    }

    //****************************************
    //While loop to create MAX_CIRCLES circles
    
    // let numCircles = 0;
    // while (numCircles < MAX_CIRCLES) {
    //     let circle = new Circle(50);

    //     //Sets the x and y position to a random position
    //     let x = Randomizer.nextInt(0, getWidth());
    //     let y = Randomizer.nextInt(0, getHeight());
    //     circle.setPosition(x, y);

    //     //Sets the color to a random color
    //     circle.setColor(Randomizer.nextColor());
    //     add(circle);

    //     //Increases the counter for the number of circles
    //     numCircles++;
    // }
}

main();