function main() {
    // create the variable isPlayerOne
    
    //write an if/else statement to print out whose turn it is

    
    //switch turns and print out whose turn it is

    
    //switch turns again and print out whose turn it is

}

