function main() {
for (let i = 500; i >= 0; i= i-7) {
console.log(i);
}
}

main();