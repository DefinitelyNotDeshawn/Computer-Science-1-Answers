/*
 * This program is a game for practicing logical operators
 * 
 *
 *
 * Click the Run button to play the game. Based on the values
 * of the X and Y variables, click either the true or false
 * button that matches the boolean expression in yellow.
 * 
 * If you want to see the code for the game, scroll down.
 *
 */
 
 
 
 
 
 
 
 
 
 
 
 
 
 

let booleanButtons = [];
let targetLabel;
let xBoolean;
let yBoolean;
let xLabel;
let yLabel;
let titleLabel1;
let titleLabel2;
let titleLabel3;
let feedback;

const resetTime = 1000;

function main(){
    startGame();
    mouseClickMethod(handleClick);
}

function startGame(){
    setBackground();
    addAnswerLabels();
    generateRandomTarget();
    addXYLabels();
    titleLabel1 = displayTitle("If the X and Y variables are:", getWidth() / 2, 40);
    titleLabel2 = displayTitle("What is this expression?", getWidth() / 2, 210);
    titleLabel3 = displayTitle("or", getWidth() / 2, getHeight()*4/5);
}

function setBackground(){
    let background = new Rectangle(getWidth(), getHeight());
    let color = new Color(210,180,222)
    background.setColor(color);
    add(background);
}

function displayTitle(titleString, x, y) {
    let title = new Text(titleString, "15pt Courier");
    title.setPosition(x - title.getWidth() / 2, y);
    title.setColor(Color.white);
    add(title);
    return(title);
}

function addXYLabels(){
    xBoolean = Randomizer.nextBoolean();
    yBoolean = Randomizer.nextBoolean();
    let xText = "X = " + xBoolean;
    let yText= "Y = " + yBoolean;
    
    
    xLabel = new Text(xText, "20pt Courier");
    xLabel.setColor(Color.white);
    xLabel.setPosition(getWidth()/2 - xLabel.getWidth()/2, 100);
    add(xLabel);
    
    yLabel = new Text(yText, "20pt Courier");
    yLabel.setColor(Color.white);
    yLabel.setPosition(getWidth()/2 - yLabel.getWidth()/2, 150);
    add(yLabel);
}

function addAnswerLabels(){
    let rectColor = new Color(245, 176, 65);
    
    let labelTrue = new Text("true", "30pt Courier");
    labelTrue.setColor(Color.white);
    labelTrue.setAnchor({ vertical: 0.5, horizontal: 0.5 });
    labelTrue.setPosition(getWidth()/2-100, getHeight()*4/5);
    
    const trueRect = new Rectangle(labelTrue.getWidth()+10, labelTrue.getHeight()+10);
    trueRect.setColor(rectColor);
    trueRect.setAnchor({ vertical: 0.5, horizontal: 0.5 });
    trueRect.setPosition(getWidth()/2-100, getHeight()*4/5);
    
    add(trueRect);
    add(labelTrue);
    
    let labelFalse = new Text("false", "30pt Courier");
    labelFalse.setColor(Color.white);
    labelFalse.setAnchor({ vertical: 0.5, horizontal: 0.5 });
    labelFalse.setPosition(getWidth()/2+100, getHeight()* 4/5);
    
    const falseRect = new Rectangle(labelFalse.getWidth()+10, labelFalse.getHeight()+10);
    falseRect.setColor(rectColor);
    falseRect.setAnchor({ vertical: 0.5, horizontal: 0.5 });
    falseRect.setPosition(getWidth()/2+100, getHeight()* 4/5);
    
    add(falseRect);
    add(labelFalse);
    
    booleanButtons.push(labelTrue);
    booleanButtons.push(labelFalse);
}

function generateRandomTarget(){
    let targetOptions = ["X && Y", "X || Y", "!X", "!Y"];
    let target = targetOptions[Randomizer.nextInt(0, 3)];
    
    targetLabel = new Text(target, "20pt Courier");
    targetLabel.setColor(Color.yellow);
    targetLabel.setPosition(getWidth()/2 - targetLabel.getWidth()/2, getHeight()/2 + 20);
    add(targetLabel);
}

function handleClick(e){
    let elem = getElementAt(e.getX(), e.getY());
    let buttonIndex = booleanButtons.indexOf(elem);
    
    if (buttonIndex != -1) {
        let button = booleanButtons[buttonIndex];
        let boolean = button.getText();
        removeLabels();

        if(checkAnswer(boolean)){
            feedback = displayTitle("Nice!", getWidth() / 2, 40);
        } else {
            feedback = displayTitle("Not Quite", getWidth() / 2, 40);
        }

        setTimeout(reset, resetTime);
    }
}

function reset(){
    removeLabels();
    titleLabel1 = displayTitle("If the X and Y variables are:", getWidth() / 2, 40);
    titleLabel2 = displayTitle("What is this expression?", getWidth() / 2, 210);
    generateRandomTarget();
    addXYLabels();
}

function removeLabels() {
    remove(titleLabel1);
    remove(titleLabel2);
    remove(targetLabel);
    remove(xLabel);
    remove(yLabel);
    remove(feedback);
}

function checkAnswer(boolean){
    let userAnswer = boolean;
    if(targetLabel.getText() == "X && Y" && xBoolean == true && yBoolean == true){
        if(userAnswer == "true"){
            return true;
        }else{
            return false;
        }
    }
    
    if(targetLabel.getText() == "X && Y" && (xBoolean == false || yBoolean == false)){
        if(userAnswer == "false"){
            return true;
        }else{
            return false;
        }
    }
    
    if(targetLabel.getText() == "X || Y" && (xBoolean == true || yBoolean == true)){
        if(userAnswer == "true"){
            return true;
        }else{
            return false;
        }
    }
    
    if(targetLabel.getText() == "X || Y" && (xBoolean == false && yBoolean == false)){
        if(userAnswer == "false"){
            return true;
        }else{
            return false;
        }
    }
    
    if(targetLabel.getText() == "!X" && xBoolean == true){
        if(userAnswer == "false"){
            return true;
        }else{
            return false;
        }
    }
    
    if(targetLabel.getText() == "!X" && xBoolean == false){
        if(userAnswer == "true"){
           return true;
        }else{
            return false;
        }
    }
    
    if(targetLabel.getText() == "!Y" && yBoolean == true){
        if(userAnswer == "false"){
           return true;
        }else{
            return false;
        }
    }
    
    if(targetLabel.getText() == "!Y" && yBoolean == false){
        if(userAnswer == "true"){
           return true;
        }else{
            return false;
        }
    }
}

main();