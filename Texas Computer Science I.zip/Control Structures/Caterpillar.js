const NUM_CIRCLES = 15;

function main() {
	
}