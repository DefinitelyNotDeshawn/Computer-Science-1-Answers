function main() {
    let count = 0;
    let radius = 200;
    while (radius > 0) {
        let circle = new Circle(radius);
        circle.setPosition(getWidth()/2, getHeight()/2);
        if (count % 2 == 0) {
            circle.setColor("red");
        } else {
            circle.setColor("black");
        }
        add(circle);
        count++;
        radius = radius - 20;
    }
}

main();

/*
Alternative method for setting the color:
if (count == 0) {
    circle.setColor("red");
    count++; //sets count to 1
} else {
    circle.setColor("black");
    count--; //sets count back to 0
}
*/