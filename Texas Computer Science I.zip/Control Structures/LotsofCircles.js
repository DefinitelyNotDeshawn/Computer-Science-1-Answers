/*This program uses a while loop to draw MAX_CIRCLES circles on the canvas.
Each loop draws a randomly-colored circle at a random position on the canvas.
*/

//Try changing the value of MAX_CIRCLES. How does this impact the output?
const MAX_CIRCLES = 500;

function main() {
    //Creates a counter to keep track of the number of circles
    let numCircles = 0;
    
    while (numCircles < MAX_CIRCLES) {
        let circle = new Circle(50);
        
        //Sets the x and y position to a random position
        let x = Randomizer.nextInt(0, getWidth());
        let y = Randomizer.nextInt(0, getHeight());
        circle.setPosition(x, y);
        
        //Sets the color to a random color
        circle.setColor(Randomizer.nextColor());
        add(circle);
        
        //Increases the counter for the number of circles
        numCircles++;
        console.log(numCircles); //Displays the value of numCircles on the console
    }
}

main();