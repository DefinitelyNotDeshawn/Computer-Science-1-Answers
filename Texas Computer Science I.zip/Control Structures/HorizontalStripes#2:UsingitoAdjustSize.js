/*
This program uses a for loop to draw NUM_STRIPES horizontal stripes.
* Each rectangle is positioned at (0,0) and is a random color.
* The width of each rectangle is getWidth().
* The height of each rectangle is determined by the value of i.
*/


//Try changing the starting value of NUM_STRIPES. How does this impact the output?
const NUM_STRIPES = 6;
const STARTING_HEIGHT = getHeight(); //Height of the first rectangle
const STRIPE_HEIGHT = getHeight() / NUM_STRIPES; //Height of one stripe

function main() {
    for (let i = 0; i < NUM_STRIPES; i++) {
        // Uses the value of i to determine the height of each rectangle
        let rectHeight = STARTING_HEIGHT - (STRIPE_HEIGHT * i);
        console.log("i: "  + i + "; Rectangle Height: " + rectHeight);
        
        let rect = new Rectangle(getWidth(), rectHeight);
        rect.setPosition(0, 0);
        rect.debug = true;
        rect.setColor(Randomizer.nextColor());
        add(rect);
    }
}

main();