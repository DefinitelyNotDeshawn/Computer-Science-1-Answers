function main() {
    //Create a variable `playlist`
    
    //Ask the user how many quarters they put into the jukebox
    
    //Print out the available songs
    
    //Use a for loop to ask the user what songs to add to their playlist
    
    //Print out the final playlist
}