const NUM_LEVELS = 3;

function main() {
    //create level variable - start on level 1
    
    // create game loop that cycles through levels here
    
    
}

//create playLevel1 function


//create playLevel2 function


//create playLevel 3 function