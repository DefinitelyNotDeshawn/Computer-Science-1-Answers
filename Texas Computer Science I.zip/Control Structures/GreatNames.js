// This program reads the users name
// and checks if it is equivalent to "Jeremy"
function main() {
	let name = readLine("Enter name: ");
	
	if (name == "Jeremy") {
		console.log("Great name.");
	}
}

main();