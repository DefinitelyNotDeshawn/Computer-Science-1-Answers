/* This program prints a countdown from 
10 to 0. Can you change the while loop so that it 
stops the countdown at 1 instead of 0?
*/

function main() {
	let num = 10;
	
	while (num >= 0) {
		console.log(num);
		num--; //this is equivalent to num = num - 1;
	}
}

main();