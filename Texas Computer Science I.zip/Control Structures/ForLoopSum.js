// This program adds the numbers from 1 to 100.
// Try adjusting the program so that it adds numbers from 1 to 50
// CHALLENGE: Can you adjust the for loop to only add even numbers?
const MIN = 1;
const MAX = 100;

function main() {
	// Creates a variable to store the growing sum
	// Note that this variable is created OUTSIDE of the for loop
	let sum = 0;
	
	// Loops from the MIN to the MAX number of times
	for (let i = MIN; i <= MAX; i++) {
		console.log("i: " + i + "; sum: " + sum);
		
		// Adds the value of i to the variable sum
		sum = sum + i; //you can also use the shortcut sum += i;
		console.log("i + sum: " + sum);
		console.log("");
	}
	
	// Prints out the final sum
	console.log("The sum is " + sum);
}

main();