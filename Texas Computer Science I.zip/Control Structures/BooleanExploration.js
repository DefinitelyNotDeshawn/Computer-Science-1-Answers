// In this program we declare a boolean
// value to represent whether the user
// is logged in. You can compare this to the 
// string value of "true" by using the typeof function.
function main() {
	let loggedIn = true;
	console.log("loggedIn is a ");
	console.log(typeof(loggedIn));
	
	let loggedInString = "true";
	console.log("loggedInString is a ");
	console.log(typeof(loggedInString));
	
	console.log("Is the user logged in?: " + loggedIn);
	
	//Let's say the user logs out. 
	//Try assigning `false` to the loggedIn variable!

}

main();