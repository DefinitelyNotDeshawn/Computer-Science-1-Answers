// This program reads a number from the
// user and prints out whether it is
// even or odd using the modulus operator.

function main() {
	let num = readInt("Number: ");
	let isEven = num % 2 == 0;

    //try changing the condition to `isEven == true`. How does this impact the output of the program? Why?
	if (isEven) {
		console.log("Number is even.");
	} else {
		console.log("Number is odd.");
	}
}

main();