function main() {
    console.log("Do I need a raincoat?");

    //create a variable that stores whether or not it is raining
    //use the Randomizer to assign a random Boolean value
    let isRaining = Randomizer.nextBoolean();
   
    //print the value of your variable to the console
    console.log(isRaining);
   
    //use an if/else statement to print out if you need a raincoat
    if (isRaining) {
        console.log("It's raining! Yes, you should wear a raincoat!");
    } else {
        console.log("No, you do not need raincoat.");
    }
}

main();