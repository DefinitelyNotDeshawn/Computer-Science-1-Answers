/* 
This program will add up numbers from the user until they enter 0, and at the end will print the total sum. 

The program has two while loops to complete this task. The first uses the break statement and the second does not.

Try commenting out the first while loop and running the second loop to see how the two while loops accomplish the same task.
 */
function main() {
	let sum = 0;
	
	//While loop #1 with a break statement to exit the loop
	while (true) {
		let num = readInt("Enter a number or enter 0 to exit.");
		if (num == 0) {
			break;
		}
		sum += num;
		console.log("The current sum is " + sum);
	}
	
	//While loop #2 where the loop condition exits the loop
// 	let num = readInt("Enter a number or enter 0 to exit.");
// 	while (num != 0) {
// 	    sum = sum + num;
// 	    console.log("The current sum is " + sum);
// 	    num = readInt("Enter a number or enter 0 to exit.");
// 	}
	
	console.log("The total was: " + sum);
}

main();