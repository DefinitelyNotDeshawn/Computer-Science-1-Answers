/* In order to be Harry Potter, you must have a 
lightning-shaped scar and be named Harry.
Take a look at both approaches to writing the if/else statement.
*/
function main() {
    let hasScar = readBoolean("Do you have a lightning-shaped scar?");
    let isNamedHarry = readBoolean("Is your name Harry?");
    let isHarryPotter = hasScar && isNamedHarry;

    console.log("");

    console.log("APPROACH #1");
    if (isHarryPotter) {
        console.log("You're a wizard Harry!");
    } else {
        console.log("I'm sorry to say that you are not Harry Potter.");
    }

    console.log("");

    // We could also write the if statement with the Boolean expression as the condition!
    console.log("APPROACH #2");
    if (hasScar && isNamedHarry) {
        console.log("You're a wizard Harry!");
    } else {
        console.log("I'm sorry to say that you are not Harry Potter.");
    }
}

main();
