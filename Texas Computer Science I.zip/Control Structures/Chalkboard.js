function main() {
for (let i = 0; i < 100; i++) {
    console.log("I will not come late to school");
}
}

main();