// This program introduces the ! (not) 
// operator, which lets you take the
// opposite of a Boolean value. Here
// we simulate a light switch.
function main() {
	let lightOn = true;
	console.log("Light on? " + lightOn);
	lightOn = !lightOn;	
	console.log("Light on? " + lightOn);
	lightOn = !lightOn;	
	console.log("Light on? " + lightOn);	
}

main();