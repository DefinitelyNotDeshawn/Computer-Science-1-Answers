function main() {

    let isHappy = true;
    console.log(isHappy);
}

main();
}

//Create a function for each mood that "plays" a song