Write your list of 5 Boolean questions here!
1. 

2. 

3. 

4. 

5.