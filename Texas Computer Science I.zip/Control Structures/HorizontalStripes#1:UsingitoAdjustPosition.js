/*
This program uses a for loop to draw NUM_STRIPES horizontal stripes. 
* The width of each rectangle is getWidth().
* The height of each rectangle is getHeight() divided by the number of stripes.
* The x position of each rectangle is 0.
* The y position of each rectangle is determined by the value of i.
*
* Check out the console to see how i impacts the y position of each rectangle
* Also note the anchor position of each rectangle using debug mode!
*/

//Try changing the value of NUM_STRIPES. How does this impact the output?
const NUM_STRIPES = 6;
const STRIPE_HEIGHT = getHeight() / NUM_STRIPES; //Height of one stripe

function main() {
    for (let i = 0; i < NUM_STRIPES; i++) {
        let height = STRIPE_HEIGHT;
        let width = getWidth();
        let rect = new Rectangle(width, height);
        
        // Uses the value of i to determine the y position of each rectangle
        // As i increases, the rectangles are placed further down the canvas
        let y = height * i;
        console.log("i: "  + i + "; Y position: height * i = " + y);
        rect.setPosition(0, y);
        rect.debug = true;
        rect.setColor(Randomizer.nextColor());
        add(rect);
    }
}

main();