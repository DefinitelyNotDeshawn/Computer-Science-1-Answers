/*You have a weak password if your password includes your birthday 
or it is all lower case and is less than 8 letters.
*/
function main() {
	//Change the assigned values to each variable in order to confirm a secure password
	let includesBirthday = false;
	let isAllLowerCase = true;
	let lessThanEight = true;
	
	let hasWeakPassword = includesBirthday || (isAllLowerCase && lessThanEight);
	
	if (hasWeakPassword) {
	    console.log("You should change your password to something more secure!");
	} else {
	    console.log("Good for you for keeping your information secure!");
	}
}

main();