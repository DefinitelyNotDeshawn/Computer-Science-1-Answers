// This program counts to one hundred by twos using a for loop.
// Try changing the for loop to count by 5s instead!
function main() {
	for (let i = 0; i <= 100; i += 2) {
		console.log(i);
	}
}

main();