//This program prints out a statement that describes
//if they are logged in our not.

function main() {
    let loggedIn = true;
    console.log(loggedIn);
    
    //prints something based on if `loggedIn` is true or false
    if (loggedIn) {
        console.log("You are currently logged in.");
    } else {
        console.log("You are currently logged out.")
    }
    
    console.log("");
    
    //assigns loggedIn a false value
    loggedIn = false;
    console.log(loggedIn);
    
    //the same if/else statement as lines 9-13
    if (loggedIn) {
        console.log("You are currently logged in.");
    } else {
        console.log("You are currently logged out.")
    }
}

main();