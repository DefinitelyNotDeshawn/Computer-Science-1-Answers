function main() {
let hasEnoughCredits = readBoolean("Do you have enough course credits? ");
let hasMetRequirements = readBoolean("Have you met all of your graduation requirements? ");
let canGraduate = hasEnoughCredits && hasMetRequirements;
console.log("Can you graduate?: " + canGraduate);

}

main();