// We use comparison operators to see if 
// a grade fell into the 'B' range.
function main(){ 
	let grade = readInt("What was your grade?");
	let gotB = grade >= 80 && grade < 90;
	console.log("Got a B: " + gotB);
}

main();