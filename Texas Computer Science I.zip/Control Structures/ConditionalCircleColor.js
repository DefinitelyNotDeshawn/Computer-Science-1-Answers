// This program draws a circle on the canvas. 
// The circle's color is determined by which number the Randomizer returns. 
// Use the console beneath the canvas to see if the `number` variable value is 1, 2, or 3. 

function main() {
    //Assigns the `number` variable a value of 1, 2, or 3
    let number = Randomizer.nextInt(1, 3);
    console.log("Number: " + number);
    
    //Adds a circle to the canvas
    let circle = new Circle(50);
    circle.setPosition(getWidth() / 2, getHeight() / 2);
    add(circle);
    
    //Sets the color of the circle based on the value of the number variable
    if (number == 1) {
        circle.setColor("red");
    } else if (number == 2){
        circle.setColor("blue");
    } else {
        circle.setColor("purple");
    }
}

main();