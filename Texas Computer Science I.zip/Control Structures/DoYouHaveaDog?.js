/* This program should declare a boolean that describes whether or not you have a dog. Then it prints out an informative message to the user. */
function main() {
	let myBoolean = true;
	console.log("Do you have a dog ");
	console.log(typeof(myBoolean));
	
    let anotherBoolean = false;
	console.log("Do you NOT have a dog ");
	console.log(typeof(anotherBoolean));
	
	console.log("Dou you have a dog?: " + myBoolean);
	


}

main();