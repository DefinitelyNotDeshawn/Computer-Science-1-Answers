//Try changing the conditions of this for loop!
//Can you make it repeat 10 times?
//Can you make it start at 1 instead of 0?
function main() {
	for (let i = 0; i < 3; i++) {
		console.log("The value of i: " + i);
	}
}

main();