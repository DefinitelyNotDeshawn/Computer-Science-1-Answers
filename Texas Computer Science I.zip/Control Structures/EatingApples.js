// This program uses a for loop to count the number of apples.
// During each loop, one of the apples is eaten.
// Try changing the for loop so that there are 100 apples to start with.
function main() {
	for (let i = 10; i > 0; i--) {
		console.log("There are " + i + " apples.");
		console.log('I eat an apple. Yummmmm.');
		console.log("");
	}
	console.log("");
	console.log("All of the apples are gone!");
	
}

main();