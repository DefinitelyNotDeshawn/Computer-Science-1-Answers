/* This program uses a while loop to create a colorful, geometric image. 
Each loop draws a rectangle that is a random color and is positioned
at (0, 0). The width and height of each rectangle decrease by 
DECREMENT each loop. */

//Creates a constant that determines how much the rectangle shrinks during each loop.
//Try adjusting this value. How does it impact the program?
const DECREMENT = 40;

function main() {
    //Creates a variable to store the width and height of the rectangles
    //Starts the width and height as the size of the canvas
    let width = getWidth();
    let height = getHeight();
    
    while (width > 0) {
        var rect = new Rectangle(width, height);
        rect.setPosition(0, 0);
        rect.setColor(Randomizer.nextColor());
        add(rect);
        
        //Decreases the width and height so that each rectangle gets smaller
        width = width - DECREMENT;
        height = height - DECREMENT;
    }
}

main();