// This program creates a rectangle or a circle based on user input
// Run the program a few times to see how it works!
// You can use the console under the canvas to see the input from the user!

function main() {
    let shape = readLine("What shape should I draw: rectangle or circle? ");
    
    // Can you revise the if/else statement to be different yet achieve the same output?
    if (shape == "rectangle") {
        drawRectangle();
    } else {
        drawCircle();
    }
}

function drawRectangle() {
    let rect = new Rectangle(100, 150);
    rect.setPosition(200, 200);
    rect.setColor("blue");
    add(rect);
}

function drawCircle() {
    let circle = new Circle(100);
    circle.setPosition(200, 200);
    circle.setColor("blue");
    add(circle);
}

main();