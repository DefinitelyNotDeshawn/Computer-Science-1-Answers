// Create all of your const variables here

function main() {

}