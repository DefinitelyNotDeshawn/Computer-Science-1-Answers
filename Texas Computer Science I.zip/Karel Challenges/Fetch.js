// play WarioWare Twisted.

function main() {
    turnLeft();
    move4Times();
    turnRight();
    moveTwice();
    takeBall();
    turnAround();
    moveTwice();
    turnLeft();
    move4Times();
    turnLeft();
    putBall();
}

function move4Times() {
    move();
    move();
    move();
    move();
}

function moveTwice() {
    move();
    move();
}

main();