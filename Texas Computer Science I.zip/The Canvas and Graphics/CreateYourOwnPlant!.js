const CENTER_X = getWidth()/2;
const CENTER_Y = getHeight()/2;
const RADIUS = 40;
const COLOR = "yellow";

function main() {
    drawFlower();
}

function drawFlower() {
    let ball = new Circle(RADIUS);
    ball.setPosition(CENTER_X, CENTER_Y);
    ball.setColor(COLOR);
    ball.debug = true;
    add(ball);
}

function drawStem() {
    let rect = new Rectangle(200, 50);
    rect.setPosition(100, 200);
    rect.setColor("blue");
}
main();