function main() {
    drawBox();    
    drawBall();
}

function drawBall() {
    let circle = new Circle(30);
    circle.setPosition(200, 350);
    circle.setColor("purple");
    circle.debug = false;
    // Adds the circle to the canvas
    add(circle);
}

function drawBox() {
    let rect = new Rectangle(100, 200);
    rect.setPosition(150, 200);
    rect.setColor("blue");
    rect.debug = false;
    add(rect);
}

main();