const POLE_HEIGHT = 300;
const POLE_WIDTH = 10;
const FLAG_HEIGHT = 150;
const FLAG_WIDTH = 250;

function main() {
    drawFlagPole();
    drawFlag();
}

function drawFlagPole() {
    let rect = new Rectangle(POLE_WIDTH, POLE_HEIGHT);
    rect.setPosition(50, 50);
    rect.setColor("orange");
    rect.debug = false;
    add(rect);
}

function drawFlag() {
    let rect = new Rectangle(FLAG_WIDTH, FLAG_HEIGHT);
    rect.setPosition(100, 70);
    rect.setColor("purple");
    rect.debug = false;
    add(rect);
}

main();