const WARIO_IMAGE = "https://codehs.com/uploads/a3cb492ff4660fa848a24eee6cce0354"

function main() {
    addText();
    addImage();
}

function addText(){
    let text = new Text("wario", "30pt Arial");
    text.setPosition(125, 100);
    text.setColor("yellow");
    text.debug = true;
    add(text);  

function addImage(){
    let wario = new WebImage(WARIO_IMAGE);
    wario.setPosition(100, 50);
    wario.setSize(200, 200);
    wario.debug = true;
    add(wario);
}

}

main();