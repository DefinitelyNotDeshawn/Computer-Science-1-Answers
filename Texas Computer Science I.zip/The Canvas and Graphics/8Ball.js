/* This program creates an 8 ball by adding a circle and
the number 8 as text. Notice how their position anchor
points are different. 

What's the difference between the getWidth() and getHeight()
functions used for CENTER_X and CENTER_Y, and the similar
looking functions for text.getWidth() and text.getHeight()?
*/

const CENTER_X = getWidth()/2;
const CENTER_Y = getHeight()/2;
const RADIUS = 40;
const NUMBER = "8";
const COLOR = "black";

function main() {
    drawPoolBall();
    drawText();
}

function drawPoolBall() {
    let ball = new Circle(RADIUS);
    ball.setPosition(CENTER_X, CENTER_Y);
    ball.setColor(COLOR);
    ball.debug = true;
    add(ball);
}

function drawText() {
    let text = new Text(NUMBER);
    let textWidth = text.getWidth();
    let textHeight = text.getHeight();
    text.setPosition(CENTER_X - textWidth/2, CENTER_Y + textHeight/2);
    text.setColor("white");
    text.debug = true;
    add(text);
}

main();