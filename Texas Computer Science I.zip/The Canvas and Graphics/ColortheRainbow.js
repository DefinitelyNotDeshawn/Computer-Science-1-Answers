/* This program creates a vertical rainbow out of rectangles! */

const COLOR_COUNT = 7;
const COLOR_WIDTH = getWidth() / COLOR_COUNT;
const COLOR_HEIGHT = getHeight();

function main() {
    addRedStripe();
    addOrangeStripe();
    addYellowStripe();
    addGreenStripe(0);
    addBlueStripe();
    addIndigoStripe();
    addVioletStripe();
}

function addRedStripe() {
    let stripe = new Rectangle(COLOR_WIDTH, COLOR_HEIGHT);
    stripe.setPosition(0, 0);
    stripe.setColor("red");
    stripe.debug = false;
    add(stripe);
}

function addOrangeStripe() {
    let stripe = new Rectangle(COLOR_WIDTH, COLOR_HEIGHT);
    stripe.setPosition(COLOR_WIDTH, 0);
    stripe.setColor("orange");
    stripe.debug = false;
    add(stripe);
}

function addYellowStripe() {
    let stripe = new Rectangle(COLOR_WIDTH, COLOR_HEIGHT);
    stripe.setPosition(COLOR_WIDTH * 2, 0);
    stripe.setColor("yellow");
    stripe.debug = false;
    add(stripe);
}

function addGreenStripe() {
    let stripe = new Rectangle(COLOR_WIDTH, COLOR_HEIGHT);
    stripe.setPosition(COLOR_WIDTH * 3, 0);
    stripe.setColor("green");
    stripe.debug = false;
    add(stripe);
}

function addBlueStripe() {
    let stripe = new Rectangle(COLOR_WIDTH, COLOR_HEIGHT);
    stripe.setPosition(COLOR_WIDTH * 4, 0);
    stripe.setColor("blue");
    stripe.debug = false;
    add(stripe);
}

function addIndigoStripe() {
    let stripe = new Rectangle(COLOR_WIDTH, COLOR_HEIGHT);
    stripe.setPosition(COLOR_WIDTH * 5, 0);
    stripe.setColor("indigo");
    stripe.debug = false;
    add(stripe);
}

function addVioletStripe() {
    let stripe = new Rectangle(COLOR_WIDTH, COLOR_HEIGHT);
    stripe.setPosition(COLOR_WIDTH * 6, 0);
    stripe.setColor("violet");
    stripe.debug = false;
    add(stripe);
}

main();