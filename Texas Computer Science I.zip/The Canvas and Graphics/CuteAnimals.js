/* This program adds two (cute) images to the canvas. Try
changing the size of the images and see what happens! */

function main() {
    addImage1();
    addImage2();
}

function addImage1() {
    let image = new WebImage("https://codehs.com/uploads/3b92763f68e09e7fd883b99fe715fe71");
    image.setSize(150, 120);
    image.setPosition(40, 50);
    add(image);
}

function addImage2() {
    let image = new WebImage("https://codehs.com/uploads/c7db97825427a35f0beb947d6ea41e7d");
    image.setSize(150, 120);
    image.setPosition(210, 50);
    add(image);
}

main();