/* This program adds a few different graphics objects 
(rectangle, image, and text). Notice how their position
anchor points (the red dot in debug mode) compare. 

What happens if you give the spaceship and greeting the
same coordinate? What you have to do to get them to overlap?
*/

const EARTH_IMAGE = "https://codehs.com/uploads/481d64784eda38ca0e1aeecb365b3229";
const SHIP_IMAGE = "https://codehs.com/uploads/708dbeeea9734cc271cb20b8a1bb5bc6";

function main(){
    addSpace();
    addGreeting();
    addSpaceShip();
    addEarth();
    
}

function addSpace(){
    let space = new Rectangle(500, 500);
    space.debug = true;
    add(space);
}

function addGreeting(){
    let text = new Text("Greetings, Earth!", "30pt Arial");
    text.setPosition(25, 300);
    text.setColor("green");
    text.debug = true;
    add(text);
}



function addEarth(){
    let earth = new WebImage(EARTH_IMAGE);
    earth.setPosition(100, 50);
    earth.setSize(200, 200);
    earth.debug = true;
    add(earth);
}

main();