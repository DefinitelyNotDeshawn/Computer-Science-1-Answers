/* This is one example of what students will create, as their hour and
minute hands will point to a variety of times. */

function main() {
    addClockFace();
    addMinuteHand();
    addHourHand();
}

function addClockFace() {
    let clock = new WebImage("https://codehs.com/uploads/ebf7e398375cde10b6937dcabfec3eff");
    clock.setPosition(0, 0);
    clock.setSize(200, 200);
    add(clock);
}

function addMinuteHand() {
    let hand = new Line(100, 100, 100, 10);
    hand.setLineWidth(3);
    add(hand);
}

function addHourHand() {
    let hand = new Line(100, 100, 70, 150);
    hand.setLineWidth(4);
    add(hand);
}

main();