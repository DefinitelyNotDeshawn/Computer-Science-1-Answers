/* This program creates a circle, customizes its properties, and then adds it
to the canvas. Try changing its properties and see what happens! Notice debug
mode is on at the moment! */

function main() {
    // Creates a new graphics circle
    let circle = new Circle(50);
    // Sets the position of the circle's anchor
    circle.setPosition(100, 100);
    // Sets the color of the circle
    circle.setColor("orange");
    // Sets debug mode on or off (change to 'true' to see anchoring)
    circle.debug = true;
    // Adds the circle to the canvas
    add(circle);
}

main();