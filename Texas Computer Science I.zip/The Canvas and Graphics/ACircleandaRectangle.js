/* This program adds a circle and a rectangle to the canvas.
Notice how their position anchor points are different. Try
changing the values in each function and see what happens
to the shapes. */

function main() {
    drawCircle();
    drawRectangle();    
}

function drawCircle() {
    // Creates a new graphics circle
    let circle = new Circle(100);
    // Sets the position of the circle's anchor
    circle.setPosition(100, 300);
    // Sets the color of the circle
    circle.setColor("purple");
    // Turns on debug mode in order to see the anchor
    circle.debug = true;
    // Adds the circle to the canvas
    add(circle);
}

function drawRectangle() {
    // Creates a new graphics rectangle
    let rect = new Rectangle(300, 30);
    // Sets the position of the rectangles's anchor
    rect.setPosition(50, 100);
    // Sets the color of the rectangle
    rect.setColor("blue");
    // Turns on debug mode in order to see the anchor
    rect.debug = true;
    // Adds the rectangle to the canvas
    add(rect);
}

main();