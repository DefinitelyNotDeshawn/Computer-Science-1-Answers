// A built-in object is a collection of useful functions that have been pre-made
// so that we can use them in our programs.

// Built into JS is an object called Math.
// We can use these functions by calling the Math library before the name 
// of the function.

//Here are a couple of useful Math functions:
console.log("Useful Math functions:");

//Find the square root:
let squareRoot = Math.sqrt(64);
console.log("The square root of 64 is "+ squareRoot);

//Raise a number to a specific power - Math.pow(base,power):
let exponent = Math.pow(3, 3);
console.log("3^3 is equal to " + exponent);

//There is no square() function, but you can use the pow() function:
let square = Math.pow(5, 2);
console.log("5 squared is equal to " + square);

//find the absolute value:
let absolute = Math.abs(-123);
console.log("The absolute value of -123 is " + absolute);

//round a number to nearest integer:
let rounded = Math.round(3.423422352352);
console.log("3.423422352352 rounded to the nearest integer is " + rounded);

//You can learn more about the Math library by checking out the DOCS tab!

console.log("\n");

//Another useful object that we can use is Number.
console.log("*******Number Library*******");

//Number allows us to find the highest number that can be stored in our programs:
let maxNumber = Number.MAX_VALUE;
console.log("The highest number we can store in JS programs is: " + maxNumber);
console.log()

let maxNumberTimesTwo = maxNumber * 2;
console.log("What happens when you multiply the max number by two?: " + maxNumberTimesTwo);