function main() {
let miles = readFloat("How many miles did you run? ");
let minutes = readFloat("How many minutes did it take you? ");
let hours = minutes / 60;

let speed = miles / hours;

console.log("Speed in mph: " + speed);
}

main();