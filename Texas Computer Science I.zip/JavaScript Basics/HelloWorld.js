/* This program prints out "Hello world!" */
function main() {
	console.log("Hello world!");
}

main();