/* This program asks the user for two integers and then adds them, storing the
answer in the sum variable. */

function main() {
	let first = readInt("First number: ");
	let second = readInt("Second number: ");
	let sum = first + second;
	console.log(sum);
}

main();