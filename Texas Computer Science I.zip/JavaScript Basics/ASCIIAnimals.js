function main() {
    // Create your fish here:
    console.log("Look, a fish!");
    console.log();
    console.log("><(((('>");
    console.log();
   
    // This is just an example of what students can make on their own.
    // They should have different code for their own ASCII image.
    console.log("        (__)");    
    console.log(" `------(oo)");
    console.log("  ||    (__)    Moooo");
    console.log("  ||w--||   ");  
}

main();