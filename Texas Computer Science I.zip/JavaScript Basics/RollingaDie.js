/* This program uses a random number generator to simulate
rolling a six sided die. Can you change it to be an eight
sided die? */

function main() {
	let roll = Randomizer.nextInt(1, 6);
	console.log("You rolled a " + roll);
}

main();