//Declare a const here to represent the cost of a tshirt

function main() {

   let tshirts = readInt("how many tshirts do you want?");
   let COST_OF_SHIRT = 20;
// We must use Math.floor to make sure the result
// is an integer
	let costTotal = Math.floor(tshirts * COST_OF_SHIRT);
	
	console.log("Your total cost is $" + costTotal + " dollars.");
}

main();