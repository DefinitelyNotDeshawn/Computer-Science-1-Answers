/* This program prompts the user for their name
 * and age, and then prints it back out. */
 
function main() {
	let name = readLine("What is your name? ");
	console.log("Hello " + name + ", nice to meet you!");
	
	let age = readInt("What is your age? ");
	console.log("You are " + age + " years old.");
}

main();