// This constant represents our currency conversion rate
const DOLLARS_TO_POUNDS = 0.6462;

/* This program will ask the user for a number of dollars, then convert
the dollars to pounds */
function main() {
	console.log("This program converts USD to GBP.");
	let dollars = readFloat("How many dollars do you want to convert to pounds? ");
	
	// This is how we can convert from dollar to pounds
	let pounds = dollars * DOLLARS_TO_POUNDS;
	
	console.log("$" + dollars + " = " + pounds + " British pounds");
}

main();