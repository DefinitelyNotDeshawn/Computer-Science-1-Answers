function main() {
    console.log("My name is Deshawn Ware");
    console.log("I like emulation, comic book series, and smash brothers");

}

main();