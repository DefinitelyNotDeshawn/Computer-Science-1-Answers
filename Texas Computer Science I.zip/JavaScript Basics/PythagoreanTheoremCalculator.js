function main() {
    let a = readInt("What is the value of side a? ");
    let b = readInt("What is the value of side b? ");
    let hypotenuse = Math.sqrt(a**2 + b**2);
    console.log("Hypotenuse length: " + hypotenuse);
}

main();