function main() {
    // Gather your user input here:
    let name = readLine("What is your name?");
    let verb = readLine("Give me a verb?");
    let adjective = readLine("Give me an adjective?");
    let number = readInt("Give me a number?");
    let pluralNoun = readLine("Give me a pluralNoun?");




    
	// Print the story:
	console.log();
	console.log("Hi " + name + ", it's nice to meet you!");
	console.log("I didn't realize how " + adjective + " you are.");
	console.log("Would you like to " + verb + " " + number + " " + pluralNoun);
	console.log("with me?");
}

// Remember to call the main function here

main();