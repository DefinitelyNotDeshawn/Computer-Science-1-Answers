function main() {
    let partOfDay = "morning";
    let time = 8;
    console.log("In the " + partOfDay + " I wake up at " + time + ".");
    time = 12;
    partOfDay = "afternoon";
    console.log("In the " + partOfDay + ", I eat lunch at " + time + ".");
    partOfDay = "evening";
    time = 10;
    console.log("In the " + partOfDay + ", I go to bed at " + time + ".");
}

// Be sure to call the main function here:
main();