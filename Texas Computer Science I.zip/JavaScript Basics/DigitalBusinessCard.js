function main() {
 function printBusinessCard()
{
     
 }    
}


// Define your function here

main();