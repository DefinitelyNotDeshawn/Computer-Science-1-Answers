function main() {
    console.log("Time to practice your multiplication!");
    console.log();    
   
    let lowEnd = readInt("Lowest number you want to multiply: ");
    let highEnd = readInt("Highest number you want to multiply: ");
   
    let firstNum = Randomizer.nextInt(lowEnd, highEnd);
    let secondNum = Randomizer.nextInt(lowEnd, highEnd);
   
    console.log();
    let answer = readInt("Ok! Multiply " + firstNum + " x " + secondNum + ": ");
   
    console.log();
    console.log("The correct answer is " + (firstNum * secondNum) + "!");
}

main();