/* This program helps us divide a large number of people into groups. 
It asks the user how many total people there are, and how many people there
are per group, and it figures out how many groups there are, and how many
people are left over. */

function main() {
	let people = readInt("Number of people: ");
	let peoplePerGroup = readInt("People per group: ");
	
	// We must use Math.floor to make sure the result
	// is an integer
	let groups = Math.floor(people / peoplePerGroup);
	
	// The % operator helps us find the remainder
	let peopleLeft = people % peoplePerGroup;
	
	console.log("There are " + groups + " groups " + 
		"with " + peopleLeft + " left over.");
}

main();