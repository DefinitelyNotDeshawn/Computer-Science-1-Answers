function main(){
    let temp = readFloat("What is your temperature?");
    let tempDeviation = Math.abs(98 - temp);
   
    console.log("Your deviation is: " + tempDeviation);
}

main();