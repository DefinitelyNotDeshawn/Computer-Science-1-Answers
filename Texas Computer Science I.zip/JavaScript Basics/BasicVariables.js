/* This program explores the use of variables. Try assigning variables different
values and see what happens. */

function main() {
	// Initializes name with value "Joe"
	let name = "Joe";
	console.log("My name is " + name);
	
	// Initializes numApples with value 5
	let numApples = 5;
	console.log("Number of apples: " + numApples);
	
	// Joe eats the apples
	console.log(name + " ate " + numApples + " apples.");
	
	// Assigns new value to numApples (does NOT need to be 
	// (and cannot be) declared again)
	numApples = 0;
	console.log("Number of apples: " + numApples);
}

main();