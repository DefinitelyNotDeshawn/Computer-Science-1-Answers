function main() {
let name = readLine("What is your name? ");
let time = readInt("What time should we meet for dinner? ");

console.log("Hi " + name + ", I will meet you at " + time +
" o'clock.");
}

main();