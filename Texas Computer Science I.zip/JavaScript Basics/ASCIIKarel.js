function main () {
    printKarel();
    console.log();
    printBall();
}

function printKarel() {
    console.log("   ()_____");
    console.log("  //     O)___");
    console.log(" //           )");
    console.log("//      _____/");
}

function printBall() {
    console.log("  o,oo  ");
    console.log(" o,oooo ");
    console.log(" oooo,o ");
    console.log("  oo,o  ");
}

main();