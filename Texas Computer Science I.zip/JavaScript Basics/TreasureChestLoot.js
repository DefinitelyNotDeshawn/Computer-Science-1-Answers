function main() {
	let roll = Randomizer.nextInt(5, 20);
	console.log("You open the chest and find " + roll + " rubies!!");
}

main();