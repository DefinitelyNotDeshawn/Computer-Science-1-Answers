/* This program helps demonstrate the order in which the functions
execute. Try changing the order of lines 10 and 11! */

function main() {
    // Prints when the main() function is called
    console.log("The main function runs first.");
    
    // Calls the next two functions. Try reversing
    // lines 10 and 11 and see what happens!
    printSecond();
    printThird();
}

function printSecond() {
    console.log("This will print second.");
}

function printThird() {
    let message = "This will print third!";
    console.log(message);
}

// Calls the main() function
main();