function main(){
    let side = readFloat("What is the side length? ");
   
    //find and print the area here
    let area = Math.pow(side, 2);
    let roundedArea = Math.round(area);
    console.log("Area: " + roundedArea);
   
    //find and print the volume here
    let volume = Math.pow(side, 3);
    let roundedVolume = Math.round(volume);
    console.log("Area: " + roundedVolume);
}

main();