/* Test this program by adding calls to the printSlope function and inputting valid and invalid arguments. */

function main() {
    printSlope(0, 0, 10, 20);
    printSlope(-5, 15, 10, -30);
    printSlope(-50, 20, 30, 20);
}

// This function prints the slope of the line between the parameter
// coordinates
function printSlope(x1, y1, x2, y2) {
    let slope = (y2 - y1) / (x2 - x1);
    console.log("Slope: " + slope);
}

main();