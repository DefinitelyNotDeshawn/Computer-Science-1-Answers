function main() {
    // first and second are the parameters
function printTriangleArea(5, 10){
    let result = 1/2 * first * second;
    console.log(result);
}
}

main();