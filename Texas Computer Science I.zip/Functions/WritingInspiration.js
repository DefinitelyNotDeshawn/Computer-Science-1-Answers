function main() {
    let genre = getGenre();
    
    console.log("********");
    
    // Generates the sentence starter based on the genre the user enters
    if (genre == 1) {
        console.log("There was a secret meeting tonight, and I had to be there.");
    } else if (genre == 2 ) {
        console.log("My hands trembling, I slowly opened the door.");
    } else if (genre == 3) {
        console.log("The year was 1924.")
    } else {
        console.log("Elena loved sitting on the docks and watching the rockets disappear among the stars.")
    }
}

function getGenre() {
    console.log("Which of the following genres do you feel like today?")
    console.log("1. Adventure");
    console.log("2. Horror");
    console.log("3. Historical Fiction");
    console.log("4. SciFi");
    
    let choice = readInt("Which do you choose?: ")
    
    return choice;
}

main();