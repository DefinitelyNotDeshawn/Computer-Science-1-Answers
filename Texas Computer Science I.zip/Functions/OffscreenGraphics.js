/* This program includes an example of a function that returns a 
Boolean true or false value when called -- isOffScreen. We use it
as a condition in an if statement to check if a graphic's anchor
is off the screen. If so, we print to the console.

Try changing the argument values in the addCircle() call statements
and see what happens. Can you use the same checkOffScreen() function
to check if a rectangle is off the canvas? */

function main() {
    addCircle(100, 200, 30, "green");
    addCircle(200, 300, 30, "blue");
    addCircle(300, 600, 30, "orange");
}

// This function creates a circle with the given parameter values
function addCircle(x, y, radius, color) {
    let circle = new Circle(radius);
    circle.setPosition(x, y);
    circle.setColor(color);
    add(circle);
    
    if(isOffScreen(x, y)) {
        console.log(color + " circle's anchor is off screen");
    }
}

/* This function takes in the x and y coordinates of the circle's
anchor point and checks to see if it is off the canvas. */
function isOffScreen(x, y) {
    // Checks to see if the anchor of the graphic is off the screen
    if(x < 0 || x > getWidth() || y < 0 || y > getHeight()) {
        return true;
    } else {
        return false;
    }
    
    // The code below does the same thing as the if/else statement above.
    // Try removing the if/else and commenting the line below:
    // return (x < 0 || x > getWidth() || y < 0 || y > getHeight());
    
}

main();