/* This program uses two "x" variables, both of which 
are local to the functions they are created in. Meanwhile,
CONVERSION is a global variable that can be accessed in 
any function. */

const CONVERSION = 0.5;

function main() {
    let x = 5;
    convertNumber(x);
    
    console.log("x in main: " + x);
}

// Uncomment this code to see what happens
// console.log("x outside of main or convertNumber: " + x);

function convertNumber(x) {
    x = CONVERSION * x;
    console.log("x in convertNumber function: " + x);
}

main();