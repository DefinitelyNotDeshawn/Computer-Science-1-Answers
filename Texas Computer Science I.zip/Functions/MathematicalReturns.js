/* This program shows a few examples of functions making
a mathematical calculation then returning the result.
Notice that the printing is occurring in the main() function,
not the individual functions.

What happens if you remove the console.log() functions? Where
are the returned values? */

function main() {
	let result = sum(5, 8);
	console.log(result);
	
	let test1 = 88;
	let test2 = 95;
	console.log(average(test1, test2));
	
	let multiple = leastCommonMultiple(9, 15);
	console.log(multiple);
}

// This function returns the sum of two number parameters
function sum(first, second) {
	let total = first + second;
	return total;
}


// This function returns the average of the two integer parameters
function average(one, two) {
    return ((one + two) / 2);
}

// This function returns the least common multiple of the two integer parameters.
// (It's a great example of the power of creating a function that returns a 
// calculation... you definitely wouldn't want to have to write this multiple times!)
function leastCommonMultiple(num1, num2) {
    // The highest possible multiple is one number times the other number
    let max = num1 * num2;
    
    // This loops through all the numbers up to the max. If each of our two 
    // numbers divide in evenly, then we know it's a multiple. This will return
    // the first, smallest, multiple it finds.
    for(let i = 1; i <= max; i++) {
        if(i % num1 == 0){
            if(i % num2 == 0){
                return i;
            }
        }
    }
}

main();