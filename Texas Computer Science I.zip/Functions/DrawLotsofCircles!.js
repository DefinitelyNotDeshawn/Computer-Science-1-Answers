/*
This program creates a function that draws a circle with an 
inputted radius, color, and x and y position for its center.

Try changing the arguments and see what happens!

What happens if you change the order of the arguments in the call statements?
Do you get the same result? Why does this happen?

*/

function main() {
	drawCircle(40, "red", 100, 300);
	drawCircle(50, "green", 50, 100);
	drawCircle(50, "lavender", 200, 100);
	drawCircle(70, "#fcba03", getWidth() / 2, getHeight() / 2);
	
}

// Function creates a circle and adds it to the canvas
// Parameters: radius, color, x and y of circle's center
function drawCircle(radius, color, x, y) {
	let circle = new Circle(radius);
	circle.setColor(color);
	circle.setPosition(x, y);
	circle.debug = false;
	add(circle);
}

main();