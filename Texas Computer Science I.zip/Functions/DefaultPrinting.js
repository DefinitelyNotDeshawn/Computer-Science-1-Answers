/* This example shows what happens when you call a function with
no argument, but with and without a default value for the parameter.

What happens when you put in an argument to the call statements? What
gets printed to the console? */

function main() {
    // No argument and no default parameter
    printWithNoDefault();
    
    // No argument, but yes default parameter
    printWithDefaultValue();
    
    // One argument and one default parameter
    printMultipleParameters("Lucia");
}

function printWithNoDefault(message) {
    console.log(message);
}

function printWithDefaultValue(message = "Hi there!") {
    console.log(message);
}

function printMultipleParameters(name, message = "Greetings") {
    console.log(message + " " + name);
}

main();