/* This program demonstrates the use of a parameter to avoid
repeated code -- console.log is only written once inside
the function and uses the parameter variable and arguments
to customize the greeting */

function main() {
    printGreeting("Gabriel");
    printGreeting("Nina");
    
    let person = "Yao";
    printGreeting(person);
}

// This function prints a greeting using the name parameter
function printGreeting(name) {
    console.log("Hi " + name + ", welcome to our site!");
}

main();