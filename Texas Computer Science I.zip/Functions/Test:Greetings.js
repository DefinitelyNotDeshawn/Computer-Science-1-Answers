/* Test this program by adding calls to the printGreeting function and inputting valid and invalid arguments. */

function main() {
    printGreeting("Gabriel");
    printGreeting("Nina");
    
    let person = "Yao";
    printGreeting(person);
}

// This function prints a greeting using the name parameter
function printGreeting(name) {
    console.log("Hi " + name + ", welcome to our site!");
}

main();