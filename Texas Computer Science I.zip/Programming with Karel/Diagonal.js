/* This program has Karel lay a diagonal row of tennis balls. 
 * However, the indenting and spacing is all wrong. Can you properly 
 * indent this program and fix the spacing between words and characters? */
function main(){
    // Loop will keep Karel building a diagonal path of balls
    // until the final wall is reached.
    while(frontIsClear()  ) {
        putBall();
        move();
        turnLeft();
        move();
        for   (let i=0;i<3;i++) {
            turnLeft();
        }
    }
    putBall();
}

main();