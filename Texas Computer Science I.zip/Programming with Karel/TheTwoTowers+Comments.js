function main() {
    move();
    putBall();
    turnLeft();
    move();
    putBall();
    move();
    putBall();
    move();
    turnRight();
    move();
    move();
    turnRight();
    move();
    putBall();
    move();
    putBall();
    move();
    putBall();
    turnAround();
    move();
    move();
    move();
    turnRight();
    
	// YAHBOOBAY MY DUDE, WARIO LAND 3 ON TOP!!!
}

function turnRight() {
    turnLeft();
    turnLeft();
    turnLeft();                 
}

function turnAround(){
    turnLeft();
    turnLeft();
}

main();