function main() {
    while (ballsPresent()) {
        move();
    }
}

main();