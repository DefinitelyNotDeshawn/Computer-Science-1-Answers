function main() {
    move();
    putBall();
    turnLeft();
    move();
    putBall();
    move();
    putBall();
    move();
    turnRight();
    moveTwice();
    turnRight();
    move();
    putBall();
    move();
    putBall();
    move();
    putBall();
    turnAround();
    moveTwice();
    move();
    turnRight();
    
	// Write your code here

}

function moveTwice(){
    move();
    move();
}

main();