function main() {

    if (facingEast()) {
        move();
    }
    
    if (facingSouth()) {
        turnLeft();
         move();
    } 
}

main();