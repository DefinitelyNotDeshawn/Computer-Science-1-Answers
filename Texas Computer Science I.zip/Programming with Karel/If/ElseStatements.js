function main() {
	move();
	if (frontIsClear()) {
		move();
	} else {
		turnLeft();
	}
}

main();