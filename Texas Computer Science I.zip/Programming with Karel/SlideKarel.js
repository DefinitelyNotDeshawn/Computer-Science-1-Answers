function turnRight() {
    turnLeft();
    turnLeft();
    turnLeft();                 
}


putBall();
turnRight();
move();
turnLeft();
move();
putBall();
turnRight();
move();
turnLeft();
move();
putBall();