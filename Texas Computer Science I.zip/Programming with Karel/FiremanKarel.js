function turnRight() {
    turnLeft();
    turnLeft();
    turnLeft();                 
}
turnRight();
move();
move();
move();
turnLeft();