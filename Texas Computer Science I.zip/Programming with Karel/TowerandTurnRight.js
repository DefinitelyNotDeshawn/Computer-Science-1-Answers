function turnRight() {
	turnLeft();
	turnLeft();
	turnLeft();
}

move();
turnLeft();
putBall();
move();
putBall();
move();
putBall();
move();
turnRight();
move();
turnRight();
move();
move();
move();
turnLeft();