function main() {
	safeTakeBall();
	move();
	safeTakeBall();
}

function safeTakeBall() {
	if (ballsPresent()) {
		takeBall();
	}
}

main();