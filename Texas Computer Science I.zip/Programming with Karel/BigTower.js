function main() {
    turnNorth();
    buildTower();
}

function turnNorth() {
    while (notFacingNorth()) {
        turnLeft();
    }
}

function buildTower() {
    while (frontIsClear()) {
        putBall();
        move();
    }
    putBall();
}

main();