function main() {
	checkDirection();
}

function checkDirection() {
    if (facingSouth()) {
        turnLeft();
    } else {
        turnLeft();
        turnLeft();
    }
}

main();