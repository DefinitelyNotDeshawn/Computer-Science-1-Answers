function main() {
    if (facingNorth()){
        makeRightSquare();
    } else {
        makeLeftSquare();
    }
}

function makeRightSquare(){
    for (let i = 0; i < 4; i++){
        putBall();
        move();
        turnRight();
    }
}

function makeLeftSquare(){
    for (let i = 0; i < 4; i++){
        putBall();
        move();
        turnLeft();
    }
}

main();