function turnAround() {
	turnLeft();
	turnLeft();
}

move();
turnAround();