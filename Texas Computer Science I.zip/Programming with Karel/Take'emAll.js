function main() { 
	move();
	for (let i = 0; i < 100; i++) {
	    takeBall();
    }
    move();
}

main();