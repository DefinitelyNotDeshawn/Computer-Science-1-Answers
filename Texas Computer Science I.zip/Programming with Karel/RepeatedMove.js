/*
 * This short program has karel move forward
 * 9 locations to the edge of the world.
 */
function main() {
    for (let i = 0; i < 9; i++) {
	    move();
    }
}

main();