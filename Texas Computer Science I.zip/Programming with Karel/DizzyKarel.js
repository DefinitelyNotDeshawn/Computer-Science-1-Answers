function main() {
    for (let i = 0; i < 32; i++) {
	    turnLeft();
    }
}

main();