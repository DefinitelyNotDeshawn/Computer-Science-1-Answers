move();
putBall();
putBall();
move();