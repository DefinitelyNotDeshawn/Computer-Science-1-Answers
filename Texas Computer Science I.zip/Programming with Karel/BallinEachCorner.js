function main(){
    
    putBall();
    for (let i = 0; i < 5; i++) {
	    move();
    }
    putBall();
    turnLeft();
    for (let i = 0; i < 5; i++) {
	    move();
    }
     putBall();
    turnLeft();
    for (let i = 0; i < 5; i++) {
	    move();
    }
     
     putBall();
    turnLeft();
    for (let i = 0; i < 5; i++) {
	    move();
	  
    }
}
 main();
 turnLeft();