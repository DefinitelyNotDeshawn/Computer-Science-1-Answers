function main() {
    
    while (noBallsPresent()) {
        putBall();
        if (frontIsClear()) {
            move();
        }
    }
}

main();