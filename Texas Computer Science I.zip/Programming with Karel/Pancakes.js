function moveTwice(){
    move();
    move();
}
function makePancakes(){
    putBall();
    putBall();
    putBall();
}

move();
makePancakes();
moveTwice();
makePancakes();
moveTwice();
makePancakes();
move();