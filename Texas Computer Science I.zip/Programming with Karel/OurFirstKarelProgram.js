move();
move();
putBall();
move();
move();