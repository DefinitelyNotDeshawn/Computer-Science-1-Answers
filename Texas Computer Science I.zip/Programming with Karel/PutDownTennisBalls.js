/*
 * This program has karel put down 6 balls
 * and then move forward one location.
 */
function main() {
    // Loop will repeat 6 times before exiting
    for (let i = 0; i < 6; i++) {
	    putBall();
    }

    move();
}

main();