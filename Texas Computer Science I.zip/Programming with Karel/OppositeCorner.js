/* Karel needs to move to the opposite 
 * corner of the world facing East. */

function main() {
    moveToWall();
    turnLeft();
    moveToWall();
    turnRight();
}

/* This function moves Karel to the end 
 * of the row.
 */
function moveToWall() {
    while (frontIsClear()) {
        move();
    }
}

main();