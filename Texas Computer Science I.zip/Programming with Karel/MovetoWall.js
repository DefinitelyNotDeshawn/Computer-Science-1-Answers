function main() {
	while (frontIsClear()) {
		move();
	}
}

main();