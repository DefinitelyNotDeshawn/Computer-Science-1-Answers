function main(){
    
    if (noBallsPresent()) {
        putBall();
        move();
    }

    if (ballsPresent()) {
        move();
    }
}

main();