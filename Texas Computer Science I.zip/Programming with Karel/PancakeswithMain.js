function main(){
    move();
    move();
}
function makePancakes(){
    putBall();
    putBall();
    putBall();
}

move();
makePancakes();
main();
makePancakes();
main();
makePancakes();
move();